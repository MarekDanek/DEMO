 <script>
	import Canvas from './Canvas.svelte';
	
  </script>

<Canvas/>


	<style>


  </style>
  
